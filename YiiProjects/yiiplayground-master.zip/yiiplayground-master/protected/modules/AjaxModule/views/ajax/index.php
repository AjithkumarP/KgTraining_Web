<?php $this->breadcrumbs = array('Interface'); ?>

index page..