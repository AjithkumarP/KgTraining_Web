<?php $this->breadcrumbs = array('Date & time'); ?>

index page..