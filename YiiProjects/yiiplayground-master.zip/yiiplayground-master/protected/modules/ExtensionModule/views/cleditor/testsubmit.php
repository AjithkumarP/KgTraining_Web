
<div style="position: relative; min-height:150px; border: 2px dotted #DDD;padding:5px">
    <p><i>The following <b>raw content</b> has been submitted by your form's editor</i></p>
    <?php echo htmlentities($value); ?>
</div>
<p></p>