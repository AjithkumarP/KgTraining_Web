<?php $this->breadcrumbs = array('Other'); ?>

index page..