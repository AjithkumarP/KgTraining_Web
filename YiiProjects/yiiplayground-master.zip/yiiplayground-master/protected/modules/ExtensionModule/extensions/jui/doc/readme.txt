Welcome to JUI 2.0, the Yii wrappers for jQuery UI.

If you need further information on jQuery or jQuery UI please check:

http://www.jquery.com/
http://www.jqueryui.com/

If you need more information on Yii, go to:

http://www.yiiframework.com/

And if you need more information on this extension, go to:

http://www.yiiframework.com/extension/jui/
