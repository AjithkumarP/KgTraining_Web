<h1> Your Cart </h1>
<strong> Products : </strong> <?php echo $products; ?><br/>
<strong> Total Prices  : </strong> <?php echo $prices; ?><br/>
