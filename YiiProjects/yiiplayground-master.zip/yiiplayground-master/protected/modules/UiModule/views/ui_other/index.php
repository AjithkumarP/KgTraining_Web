<?php $this->breadcrumbs = array('Interface', 'Other'); ?>

index page..