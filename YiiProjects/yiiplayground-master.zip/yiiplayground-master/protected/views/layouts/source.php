<div class="source_box">
    <?php echo $content; ?>
</div><!-- source_box -->

<?php $this->widget('application.extensions.syntaxhighlighter.SyntaxHighlighter', array()); ?>