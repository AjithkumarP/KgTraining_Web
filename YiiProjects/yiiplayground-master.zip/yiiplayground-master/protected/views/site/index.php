<?php $this->pageTitle = Yii::app()->name; ?>

<h1>Welcome to <i><?php echo CHtml::encode(Yii::app()->name); ?></i></h1>

<ul style="line-height: 1.6em;">
    <li><a href="https://github.com/giovdk21/yiiplayground/">Project homepage &amp; download</a></li>
    <li><a href="http://www.yiiframework.com/forum/index.php?/topic/9209-yii-playground-collaborative-demo-app/">Official forum thread</a></li>
    <li><a href="https://github.com/giovdk21/yiiplayground/wiki/How-to-contribute-to-the-Yii-Playground-project" style="font-weight: bold;">Join this project!</a></li>
</ul>